/*:
@target MZ
@author Coelocanth
@plugindesc TPB charges instantly between turns
(Version 1.0)
@help

Plug and Play.
In situations where all battlers are charging or casting, the battle
will fast forward automatically until the end of round or a battler
is ready.
The battle system on the system 1 tab of the database should be set
to "time progress (wait)". I don't recommend using this with active
mode.
*/
var CC = CC || {};
CC.InstantTPB = {};
CC.InstantTPB.BattleManager = {};
CC.InstantTPB.BattleManager.updateTpb = BattleManager.updateTpb;

Game_Battler.prototype.isTpbSkipForwardable = function() {
    return this._tpbState == "charging" || this._tpbState == "casting";
}

BattleManager.updateTpb = function() {
    do {
        CC.InstantTPB.BattleManager.updateTpb.call(this);
    }
    while(this.isInTurn() && this.allBattleMembers().length && this.allBattleMembers().every(battler => battler.isTpbSkipForwardable()))
}
